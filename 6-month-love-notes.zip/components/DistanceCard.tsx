import React from 'react';
import { DistanceResult } from '../types';
import { MapPin, Plane, ExternalLink, Link as LinkIcon } from 'lucide-react';

interface DistanceCardProps {
  data: DistanceResult | null;
  isVisible: boolean;
}

const DistanceCard: React.FC<DistanceCardProps> = ({ data, isVisible }) => {
  if (!data) return null;

  return (
    <div 
      className={`
        w-full max-w-2xl bg-white/90 backdrop-blur-xl rounded-[2.5rem] shadow-2xl p-8 md:p-12
        border border-rose-100/50 transition-all duration-1000 ease-in-out transform
        ${isVisible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-10 scale-95'}
      `}
    >
      <div className="flex justify-center mb-8">
        <div className="relative">
          <div className="absolute inset-0 bg-rose-200 blur-xl rounded-full opacity-50 animate-pulse"></div>
          <div className="relative bg-white p-4 rounded-full border border-rose-100 shadow-sm">
            <MapPin className="w-8 h-8 text-rose-500" />
          </div>
        </div>
      </div>

      <h3 className="font-serif text-3xl text-gray-800 text-center mb-6">The Bridge Between Us</h3>
      
      <div className="flex items-center justify-between mb-10 px-4 md:px-10">
        <div className="text-center">
          <p className="font-sans font-bold text-[10px] uppercase tracking-widest text-rose-400 mb-1">Vidhi</p>
          <p className="font-serif text-lg text-gray-700">IIM Rohtak</p>
        </div>
        
        <div className="flex-grow flex flex-col items-center px-4 relative">
          <div className="w-full h-px bg-dashed border-t-2 border-dashed border-rose-200 mb-2"></div>
          <Plane className="w-5 h-5 text-rose-300 absolute -top-2 animate-[float_4s_infinite_ease-in-out]" />
          <span className="text-[10px] font-sans font-bold text-gray-400 uppercase tracking-tighter">Connected by Heart</span>
        </div>

        <div className="text-center">
          <p className="font-sans font-bold text-[10px] uppercase tracking-widest text-rose-400 mb-1">Jinen</p>
          <p className="font-serif text-lg text-gray-700">Mumbai</p>
        </div>
      </div>

      <div className="bg-rose-50/50 rounded-3xl p-8 md:p-10 border border-rose-100/50 mb-10">
        <p className="font-serif text-xl md:text-2xl text-rose-600 italic leading-relaxed text-center font-bold">
          "Distance is a test of how far love can travel."
        </p>
      </div>

      {data.links.length > 0 && (
        <div className="space-y-4">
          <p className="text-center font-sans font-bold text-[10px] uppercase tracking-widest text-gray-400">Verified via Google Maps</p>
          <div className="flex flex-wrap justify-center gap-4">
            {data.links.map((link, idx) => (
              <a 
                key={idx}
                href={link.uri}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-white border border-rose-100 rounded-full text-rose-500 text-sm font-medium hover:bg-rose-500 hover:text-white transition-all shadow-sm"
              >
                <LinkIcon className="w-3 h-3" />
                {link.title}
                <ExternalLink className="w-3 h-3 opacity-50" />
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default DistanceCard;