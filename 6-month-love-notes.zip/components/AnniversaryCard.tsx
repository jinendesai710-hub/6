import React from 'react';
import { LoveContent } from '../types';
import { Heart, Calendar, Sparkles } from 'lucide-react';

interface AnniversaryCardProps {
  content: LoveContent;
  isVisible: boolean;
}

const AnniversaryCard: React.FC<AnniversaryCardProps> = ({ content, isVisible }) => {
  const getStaggerClass = (delay: string) => `
    transform transition-all duration-700 ease-out
    ${isVisible ? `opacity-100 translate-y-0 ${delay}` : 'opacity-0 translate-y-4 delay-0'}
  `;

  return (
    <div 
      className={`
        w-full max-w-2xl bg-white/90 backdrop-blur-xl rounded-[2rem] md:rounded-[2.5rem] shadow-[0_20px_50px_rgba(244,63,94,0.15)] p-6 md:p-12
        border border-white/60 transform transition-all duration-1000 cubic-bezier(0.23, 1, 0.32, 1)
        ${isVisible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-10 scale-95'}
      `}
    >
      {/* Header - Stagger 1 */}
      <div className={`text-center mb-10 md:mb-12 ${getStaggerClass('delay-100')}`}>
        <h2 className="font-script text-5xl md:text-7xl text-rose-500 mb-6 drop-shadow-sm">Half a Year</h2>
        
        <div className="space-y-4 px-2 md:px-4">
          <p className="font-serif text-base md:text-lg text-gray-700 leading-relaxed italic">
            Even though we’re miles apart, it feels like you’re right here with me. Every thought of you makes the distance seem smaller, and every message from you reminds me that love doesn’t measure in kilometers. I may not be able to hold you now, but I’m holding you in my heart, always.
          </p>
          <p className="font-serif text-base md:text-lg text-gray-700 leading-relaxed italic">
            Missing you is hard baby, but it’s also proof of how deeply I care. Every little thing reminds me of you—your laugh, your smile, the way you say my name. Even in the quiet moments when we’re apart, I feel you vidhi. And that feeling is enough to keep me going.
          </p>
        </div>
        
        <div className="mt-8 flex items-center justify-center gap-2 text-gray-400 font-sans text-[9px] md:text-[10px] tracking-[0.4em] uppercase font-bold">
           <div className="h-px w-4 bg-rose-200"></div>
           Six Months of Devotion
           <div className="h-px w-4 bg-rose-200"></div>
        </div>
      </div>

      {/* A Letter for Your Soul - Stagger 2 */}
      <div className={`mb-10 md:mb-12 space-y-4 ${getStaggerClass('delay-300')}`}>
        <div className="flex items-center gap-3 justify-center mb-4">
           <div className="h-px w-8 md:w-12 bg-rose-200"></div>
           <Heart className="w-4 h-4 md:w-5 md:h-5 text-rose-400 fill-rose-400" />
           <div className="h-px w-8 md:w-12 bg-rose-200"></div>
        </div>
        
        <div className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] border border-white/80 shadow-sm">
          <h3 className="font-sans font-bold text-rose-800/60 text-[9px] md:text-[10px] uppercase tracking-[0.2em] mb-6 md:mb-8 text-center">A Letter for Your Soul</h3>
          <div className="text-gray-700 font-serif text-sm md:text-base text-justify leading-relaxed space-y-4 md:space-y-5">
            <p>
              Six months of us. Same country, different cities, and somehow a distance that taught me more about love than closeness ever could. These months have been filled with waiting, counting days, missed chances, and quiet hope—but also with choosing each other every single time.
            </p>
            <p>
              We’ve loved knowing we’re not impossibly far, yet still far enough to miss each other deeply. Every call, every message, every “josu” has reminded me that love isn’t about convenience—it’s about commitment.
            </p>
            <p>
              There are days I imagine how easy it would be if we were in the same place, if meeting didn’t need planning, if goodbyes weren’t part of us. But even then, I realise something important: distance hasn’t weakened us. It’s made our bond stronger. It’s made our love thoughtful, steady, and real.
            </p>
            <p>
              Thank you for staying, for believing, for loving me even when we can’t reach each other instantly. Six months in, I don’t just miss you—I trust us. And I know that when the distance finally closes, it’ll be worth everything we waited through.
            </p>
            <div className="pt-6 border-t border-rose-100/50 text-center">
              <p className="font-bold italic text-rose-600">Six months down.</p>
              <p className="font-bold italic text-rose-600">So many moments ahead.</p>
              <p className="font-bold italic text-rose-600">Will always choose you.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Date Idea Section - Stagger 3 */}
      <div className={`bg-white/40 p-6 md:p-8 rounded-[2rem] md:rounded-[2.5rem] border border-rose-100/50 shadow-inner mb-8 ${getStaggerClass('delay-500')}`}>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 md:p-2.5 bg-rose-500 rounded-full shadow-lg shadow-rose-200">
            <Calendar className="w-4 h-4 md:w-5 md:h-5 text-white" />
          </div>
          <h3 className="font-sans font-bold text-gray-800 text-[10px] md:text-[11px] uppercase tracking-[0.2em]">Our Next Chapter</h3>
        </div>
        <h4 className="font-serif text-xl md:text-2xl text-rose-600 mb-4 font-bold italic">Second favourite date idea</h4>
        <p className="text-gray-600 font-sans text-xs md:text-sm leading-relaxed opacity-90 text-justify">
          A future planning date is where you intentionally set aside time on a video call to imagine life together beyond the distance, starting with planning your next meet-up in warm, comforting detail—who travels to whom, the dates, where you’ll stay, what you’ll do the moment you see each other—then slowly expanding into dreaming up one perfect day together, from lazy mornings to late-night conversations, while sprinkling in questions like what you’re most excited for or what you’ll miss when it ends; from there, you talk gently about a distance-free version of your relationship, how weekends would look if you lived in the same city, the small habits you’d share, and eventually touch on longer-term ideas like living together or aligning future goals, keeping it light and reassuring rather than heavy, and finally ending the date with something symbolic—setting a countdown, saving the plan, or promising a small ritual until you meet again—so the conversation leaves you both feeling closer, hopeful, and reminded that the distance is temporary but the intention is real 💕
        </p>
      </div>

      {/* Quote after date idea - Stagger 4 */}
      <div className={`text-center space-y-4 mb-4 ${getStaggerClass('delay-600')}`}>
        <p className="font-serif text-lg md:text-xl text-rose-500 font-bold italic px-4 leading-relaxed">
          “Distance didn’t weaken us; it taught us how deep love can go.”
        </p>
        <div className="flex justify-center gap-3 opacity-60">
          <Sparkles className="text-yellow-400/60 w-5 h-5 animate-pulse" />
          <Sparkles className="text-rose-400/40 w-4 h-4 animate-pulse-slow" />
        </div>
      </div>
    </div>
  );
};

export default AnniversaryCard;