import React from 'react';
import { Heart, Youtube, Play } from 'lucide-react';

interface LyricSectionProps {
  isVisible: boolean;
}

const LyricSection: React.FC<LyricSectionProps> = ({ isVisible }) => {
  return (
    <div 
      className={`
        w-full max-w-2xl mx-auto px-6 py-16 md:py-24 text-center
        transition-all duration-1000 ease-in-out transform
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}
      `}
    >
      <div className="flex justify-center mb-6">
        <Heart className="w-8 h-8 text-pink-400 fill-pink-100 animate-pulse" />
      </div>

      {/* First Lyric Block */}
      <h2 className="font-serif text-3xl md:text-4xl text-pink-500 mb-10 font-light italic">
        Lyrics that make me think about you
      </h2>

      <div className="space-y-6 md:space-y-10 mb-10">
        <p className="font-serif text-xl md:text-2xl text-pink-600 font-bold leading-relaxed italic">
          And I thank God every day<br />
          For the girl He sent my way<br />
          But I know the things He gives me<br />
          He can take away<br />
          And I hold you every night<br />
          And that's a feelin' I wanna get used to<br />
          But there's no man as terrified<br />
          As the man who stands to lose you<br />
          Oh, I hope I don't lose you<br />
          Please stay<br />
          I want you, I need you, oh, God<br />
          Don't take<br />
          This beautiful girl that I've got
        </p>
      </div>

      {/* First YouTube Clip Link */}
      <div className="mb-16 flex justify-center">
        <a 
          href="https://youtube.com/clip/UgkxO0XZYaxl4FUeOh75-5tcQOvxBL0b-Udu?si=Ib0TvO_sWnEx0YaP" 
          target="_blank" 
          rel="noopener noreferrer"
          className="group relative inline-flex flex-col items-center gap-4 transition-all duration-500 hover:scale-105"
        >
          <div className="absolute inset-0 bg-rose-400 blur-2xl rounded-full opacity-10 group-hover:opacity-30 transition-opacity"></div>
          
          <div className="relative bg-white/80 backdrop-blur-md px-8 py-4 rounded-full border border-rose-100 shadow-xl shadow-rose-200/20 flex items-center gap-3">
            <div className="p-2 bg-rose-500 rounded-full text-white shadow-lg shadow-rose-200">
              <Youtube className="w-5 h-5 fill-current" />
            </div>
            <div className="text-left">
              <p className="font-sans text-[10px] font-bold tracking-[0.2em] text-gray-400 uppercase leading-none mb-1">Watch our moment</p>
              <p className="font-serif text-rose-600 font-bold italic leading-none">A piece of my heart</p>
            </div>
            <Play className="w-4 h-4 text-rose-300 ml-2 animate-pulse" />
          </div>
          
          <span className="font-sans text-[8px] uppercase tracking-widest text-gray-300 opacity-60 group-hover:opacity-100 transition-opacity">
            Click to open YouTube
          </span>
        </a>
      </div>

      {/* Divider */}
      <div className="flex justify-center items-center gap-4 mb-16">
        <div className="h-px w-16 bg-pink-200"></div>
        <Heart className="w-4 h-4 text-pink-300 fill-pink-50" />
        <div className="h-px w-16 bg-pink-200"></div>
      </div>

      {/* Second Lyric Block */}
      <h2 className="font-serif text-3xl md:text-4xl text-pink-500 mb-10 font-light italic">
        Lyrics that express my feelings for you
      </h2>

      <div className="space-y-6 md:space-y-8 mb-10">
        <p className="font-serif text-xl md:text-2xl text-pink-500 leading-relaxed italic">
          If the whole world was watching I'd still dance with you<br />
          Drive highways and byways to be there with you<br />
          Over and over the only truth<br />
          Everything comes back to you
        </p>

        <p className="font-serif text-xl md:text-2xl text-pink-600 font-bold leading-relaxed italic">
          You still make me nervous when you walk in the room<br />
          Them butterflies they come alive when I'm next to you<br />
          Over and over the only truth<br />
          Everything comes back to you
        </p>
      </div>

      {/* Second YouTube Clip Link */}
      <div className="mb-16 flex justify-center">
        <a 
          href="https://youtube.com/clip/UgkxfH8VdUK7Srz0vEdq_0xE04yBu6gbkn-k?si=vFKY9zJJyPLUpnNM" 
          target="_blank" 
          rel="noopener noreferrer"
          className="group relative inline-flex flex-col items-center gap-4 transition-all duration-500 hover:scale-105"
        >
          {/* Subtle Glow Background */}
          <div className="absolute inset-0 bg-rose-400 blur-2xl rounded-full opacity-10 group-hover:opacity-30 transition-opacity"></div>
          
          <div className="relative bg-white/80 backdrop-blur-md px-8 py-4 rounded-full border border-rose-100 shadow-xl shadow-rose-200/20 flex items-center gap-3">
            <div className="p-2 bg-rose-500 rounded-full text-white shadow-lg shadow-rose-200">
              <Youtube className="w-5 h-5 fill-current" />
            </div>
            <div className="text-left">
              <p className="font-sans text-[10px] font-bold tracking-[0.2em] text-gray-400 uppercase leading-none mb-1">Our Feelings</p>
              <p className="font-serif text-rose-600 font-bold italic leading-none">Everything comes back to you</p>
            </div>
            <Play className="w-4 h-4 text-rose-300 ml-2 animate-pulse" />
          </div>
          
          <span className="font-sans text-[8px] uppercase tracking-widest text-gray-300 opacity-60 group-hover:opacity-100 transition-opacity">
            Click to watch clip
          </span>
        </a>
      </div>

      <div className="mt-16 flex justify-center">
        <div className="flex gap-3">
          <div className="w-2 h-2 rounded-full bg-pink-200"></div>
          <div className="w-2 h-2 rounded-full bg-pink-300"></div>
          <div className="w-2 h-2 rounded-full bg-pink-200"></div>
        </div>
      </div>
    </div>
  );
};

export default LyricSection;