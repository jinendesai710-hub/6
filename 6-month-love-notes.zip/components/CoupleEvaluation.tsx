import React, { useState } from 'react';
import { Heart, Sparkles, Star } from 'lucide-react';
import { evaluateRelationship } from '../services/geminiService';
import { EvaluationResult } from '../types';

interface CoupleEvaluationProps {
  isVisible: boolean;
}

const CoupleEvaluation: React.FC<CoupleEvaluationProps> = ({ isVisible }) => {
  const [jinenThings, setJinenThings] = useState<string[]>(['', '', '', '']);
  const [vidhiThings, setVidhiThings] = useState<string[]>(['', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<EvaluationResult | null>(null);

  const handleInputChange = (
    index: number, 
    value: string, 
    setter: React.Dispatch<React.SetStateAction<string[]>>, 
    currentValues: string[]
  ) => {
    const newValues = [...currentValues];
    newValues[index] = value;
    setter(newValues);
  };

  const handleEvaluate = async () => {
    // Basic validation
    if (jinenThings.some(t => !t.trim()) || vidhiThings.some(t => !t.trim())) {
      alert("Please fill in all the nice things about each other! ❤️");
      return;
    }

    setLoading(true);
    try {
      // We still call the service to provide the 'Analyzing' experience, 
      // but we will hardcode the UI to 100% and remove the text as requested.
      const data = await evaluateRelationship(jinenThings, vidhiThings);
      setResult(data);
    } catch (error) {
      console.error(error);
      // Fallback result to trigger the UI state
      setResult({ score: 100, analysis: '', romanticSummary: '' });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
      setResult(null);
      setJinenThings(['', '', '', '']);
      setVidhiThings(['', '', '', '']);
  }

  return (
    <div 
      className={`
        w-full max-w-2xl bg-white/90 backdrop-blur-md rounded-3xl shadow-2xl p-6 md:p-8
        border border-white/50 transition-all duration-700 ease-in-out
        ${isVisible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-10 scale-95'}
      `}
    >
      <div className="text-center mb-6">
        <h2 className="font-script text-5xl text-rose-600 mb-2 drop-shadow-sm">Jinen & Vidhi</h2>
        <p className="text-gray-500 font-sans text-sm tracking-widest uppercase">The Perfect Match</p>
      </div>

      {!result ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            {/* Jinen Column */}
            <div className="bg-blue-50/50 p-4 rounded-2xl border border-blue-100">
              <div className="flex items-center gap-2 mb-4 justify-center">
                <span className="text-2xl">👰‍♂️</span>
                <h3 className="font-serif text-xl text-blue-800">About Jinen</h3>
              </div>
              <p className="text-xs text-center text-blue-600/70 mb-4 font-sans uppercase tracking-wide">4 Good Things</p>
              <div className="space-y-3">
                {jinenThings.map((thing, i) => (
                  <input
                    key={`jinen-${i}`}
                    type="text"
                    placeholder={`Trait ${i + 1}...`}
                    value={thing}
                    onChange={(e) => handleInputChange(i, e.target.value, setJinenThings, jinenThings)}
                    className="w-full bg-white/80 border border-blue-200 rounded-lg px-3 py-2 text-sm text-gray-700 placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all"
                  />
                ))}
              </div>
            </div>

            {/* Vidhi Column */}
            <div className="bg-pink-50/50 p-4 rounded-2xl border border-pink-100">
              <div className="flex items-center gap-2 mb-4 justify-center">
                <span className="text-2xl">👰‍♀️</span>
                <h3 className="font-serif text-xl text-rose-800">About Vidhi</h3>
              </div>
              <p className="text-xs text-center text-rose-600/70 mb-4 font-sans uppercase tracking-wide">4 Good Things</p>
              <div className="space-y-3">
                {vidhiThings.map((thing, i) => (
                  <input
                    key={`vidhi-${i}`}
                    type="text"
                    placeholder={`Trait ${i + 1}...`}
                    value={thing}
                    onChange={(e) => handleInputChange(i, e.target.value, setVidhiThings, vidhiThings)}
                    className="w-full bg-white/80 border border-pink-200 rounded-lg px-3 py-2 text-sm text-gray-700 placeholder-pink-300 focus:outline-none focus:ring-2 focus:ring-rose-300 transition-all"
                  />
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={handleEvaluate}
            disabled={loading}
            className={`
              w-full py-4 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-xl
              shadow-lg shadow-rose-500/30 font-sans font-medium tracking-wide flex items-center justify-center gap-2
              hover:scale-[1.02] active:scale-[0.98] transition-all duration-300
              ${loading ? 'opacity-80 cursor-wait' : ''}
            `}
          >
            {loading ? (
              <>
                <Sparkles className="w-5 h-5 animate-spin" /> Analyzing Love...
              </>
            ) : (
              <>
                <Heart className="w-5 h-5 fill-white" /> Evaluate Compatibility
              </>
            )}
          </button>
        </>
      ) : (
        <div className="animate-fade-in py-12">
          <div className="text-center mb-8">
            <div className="inline-block p-6 rounded-full bg-yellow-50 border-2 border-yellow-200 mb-8 shadow-xl">
                <div className="flex items-center gap-3 px-4">
                    <Star className="w-8 h-8 text-yellow-500 fill-yellow-500 animate-pulse" />
                    <span className="font-serif text-4xl md:text-5xl text-yellow-700 font-bold">100% Match</span>
                    <Star className="w-8 h-8 text-yellow-500 fill-yellow-500 animate-pulse" />
                </div>
            </div>
            
            <div className="max-w-md mx-auto px-4 animate-fade-in delay-300">
               <p className="font-serif text-xl md:text-2xl text-rose-600 italic font-medium leading-relaxed">
                  "It says we’re 100% compatible… which makes sense, because you feel like my safe place vidhi"
               </p>
            </div>
          </div>

          <button
            onClick={resetForm}
            className="w-full py-3 text-rose-400 font-medium hover:bg-rose-50 rounded-lg transition-colors text-sm uppercase tracking-widest mt-6"
          >
            Reset Evaluation
          </button>
        </div>
      )}
    </div>
  );
};

export default CoupleEvaluation;