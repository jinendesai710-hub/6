import React, { useState } from 'react';
import { CheckCircle2, XCircle, Trophy, BookHeart } from 'lucide-react';

interface Question {
  id: number;
  text: string;
  answer: string;
}

const questions: Question[] = [
  { id: 1, text: "When is our anniversary?", answer: "12.08.2025" },
  { id: 2, text: "When did I first touch your thigh?", answer: "26.7.2025" },
  { id: 3, text: "When did we first text?", answer: "22.03.2025" },
  { id: 4, text: "When did we first kiss?", answer: "16.08.2025" }, // Normalizing format slightly for UX, but checking is flexible
];

interface LoveQuizProps {
  isVisible: boolean;
}

const LoveQuiz: React.FC<LoveQuizProps> = ({ isVisible }) => {
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({
    1: '', 2: '', 3: '', 4: ''
  });
  const [results, setResults] = useState<Record<number, boolean | null>>({
    1: null, 2: null, 3: null, 4: null
  });
  const [quizFinished, setQuizFinished] = useState(false);

  const checkAnswer = (id: number) => {
    const q = questions.find(q => q.id === id);
    if (!q) return;

    const normalizedUser = userAnswers[id].trim().toLowerCase().replace(/\s/g, '');
    const normalizedCorrect = q.answer.trim().toLowerCase().replace(/\s/g, '');
    
    // Also support the missing dot version user provided in prompt: 16.082025
    const isCorrect = normalizedUser === normalizedCorrect || 
                     (id === 4 && normalizedUser === "16.082025");

    setResults(prev => ({ ...prev, [id]: isCorrect }));
    
    // Check if all are correct to finish
    const newResults = { ...results, [id]: isCorrect };
    if (Object.values(newResults).every(r => r === true)) {
      setQuizFinished(true);
    }
  };

  const handleInputChange = (id: number, value: string) => {
    setUserAnswers(prev => ({ ...prev, [id]: value }));
    if (results[id] !== null) {
      setResults(prev => ({ ...prev, [id]: null }));
    }
  };

  return (
    <div 
      className={`
        w-full max-w-2xl bg-white/90 backdrop-blur-md rounded-[2.5rem] shadow-2xl p-8 md:p-12
        border border-rose-100/50 transition-all duration-1000 ease-in-out
        ${isVisible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-10 scale-95'}
      `}
    >
      <div className="text-center mb-10">
        <div className="inline-block p-3 bg-rose-50 rounded-2xl mb-4">
          <BookHeart className="w-8 h-8 text-rose-500" />
        </div>
        <h2 className="font-serif text-4xl text-gray-800 mb-2">The Memory Test</h2>
        <p className="text-gray-400 font-sans text-[10px] tracking-[0.3em] uppercase font-bold">A journey through our calendar</p>
      </div>

      <div className="space-y-8">
        {questions.map((q) => (
          <div key={q.id} className="relative group">
            <label className="block font-serif text-lg text-gray-700 mb-3 pl-1">
              {q.id}. {q.text}
            </label>
            <div className="flex gap-3">
              <input
                type="text"
                placeholder="DD.MM.YYYY"
                value={userAnswers[q.id]}
                onChange={(e) => handleInputChange(q.id, e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && checkAnswer(q.id)}
                className={`
                  flex-grow bg-rose-50/30 border-2 rounded-2xl px-5 py-3 outline-none transition-all font-sans
                  ${results[q.id] === true ? 'border-green-200 bg-green-50/50' : 
                    results[q.id] === false ? 'border-rose-200 bg-rose-50/50' : 
                    'border-gray-100 focus:border-rose-300'}
                `}
              />
              <button 
                onClick={() => checkAnswer(q.id)}
                className="bg-rose-500 text-white px-6 rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-rose-600 transition-colors shadow-lg shadow-rose-200"
              >
                Check
              </button>
            </div>

            {/* Feedback Messages */}
            <div className="h-6 mt-2 pl-1">
              {results[q.id] === true && (
                <div className="flex items-center gap-2 text-green-600 animate-fade-in">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-sm font-medium italic">i love you vidhi</span>
                </div>
              )}
              {results[q.id] === false && (
                <div className="flex items-center gap-2 text-rose-500 animate-fade-in">
                  <XCircle className="w-4 h-4" />
                  <span className="text-sm font-medium italic">you owe me a kiss</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {quizFinished && (
        <div className="mt-12 p-8 bg-gradient-to-br from-rose-500 to-pink-600 rounded-[2rem] text-white text-center shadow-2xl animate-scale-in">
          <Trophy className="w-10 h-10 mx-auto mb-4 text-rose-100" />
          <h3 className="font-serif text-2xl mb-4">Every moment is a treasure...</h3>
          <p className="font-serif italic text-xl leading-relaxed opacity-95">
            "Distance is not for the fearful, it is for the bold. It's for those who are willing to spend a lot of time alone in exchange for a little time with the one they love."
          </p>
          <div className="mt-6 text-[10px] uppercase tracking-[0.4em] font-bold opacity-60">
            You remembered everything.
          </div>
        </div>
      )}
    </div>
  );
};

export default LoveQuiz;