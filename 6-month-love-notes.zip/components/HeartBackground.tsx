import React, { useEffect, useState } from 'react';

const HeartBackground: React.FC = () => {
  // Use a fixed number of hearts for performance, utilizing Tailwind animation classes
  const [hearts, setHearts] = useState<Array<{ id: number; left: string; animationDuration: string; delay: string; scale: number }>>([]);

  useEffect(() => {
    const newHearts = Array.from({ length: 20 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      animationDuration: `${Math.random() * 5 + 5}s`, // 5-10s
      delay: `${Math.random() * 5}s`,
      scale: Math.random() * 0.5 + 0.5, // 0.5 - 1.0 scale
    }));
    setHearts(newHearts);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {hearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute bottom-[-50px] text-rose-200 opacity-40 animate-float"
          style={{
            left: heart.left,
            animationDuration: heart.animationDuration,
            animationDelay: heart.delay,
            fontSize: `${heart.scale * 2}rem`,
            transform: `scale(${heart.scale})`
          }}
        >
          ❤️
        </div>
      ))}
    </div>
  );
};

export default HeartBackground;
