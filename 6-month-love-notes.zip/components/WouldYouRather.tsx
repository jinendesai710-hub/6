import React, { useState } from 'react';
import { Heart, Dices, Sparkles } from 'lucide-react';

interface ChoiceQuestion {
  id: number;
  question: string;
  answer: string;
}

const ratherQuestions: ChoiceQuestion[] = [
  { 
    id: 1, 
    question: "Would you rather kiss me once or kiss me twice?", 
    answer: "i want to keep kissing you without counting" 
  },
  { 
    id: 2, 
    question: "Would you rather kiss me for free or the hottest person in the world by paying 100 rupees?", 
    answer: "i am the hottest person in the world for you" 
  },
  { 
    id: 3, 
    question: "Would you rather go on a trip with me or stay at home with me?", 
    answer: "i want to do everything with you" 
  },
  { 
    id: 4, 
    question: "Would you rather prefer me to be a smart guy or good looking guy?", 
    answer: "you already are both baby" 
  },
  { 
    id: 5, 
    question: "Would you rather me pulling you closer or me refusing to let go?", 
    answer: "both are correct" 
  },
  { 
    id: 6, 
    question: "Would you rather miss me at night or miss me first thing in the morning?", 
    answer: "i miss you all the time baby" 
  },
  { 
    id: 7, 
    question: "Would you rather love me loudly or love me quietly but consistently?", 
    answer: "However you love, you love me." 
  }
];

interface WouldYouRatherProps {
  isVisible: boolean;
}

const WouldYouRather: React.FC<WouldYouRatherProps> = ({ isVisible }) => {
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});

  const toggleReveal = (id: number) => {
    setRevealed(prev => ({ ...prev, [id]: true }));
  };

  return (
    <div 
      className={`
        w-full max-w-2xl bg-white/90 backdrop-blur-md rounded-[2.5rem] shadow-2xl p-8 md:p-12
        border border-rose-100/50 transition-all duration-1000 ease-in-out
        ${isVisible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-10 scale-95'}
      `}
    >
      <div className="text-center mb-10">
        <div className="inline-block p-3 bg-rose-50 rounded-2xl mb-4">
          <Dices className="w-8 h-8 text-rose-500" />
        </div>
        <h2 className="font-serif text-4xl text-gray-800 mb-2">The Choice of Us</h2>
        <p className="text-gray-400 font-sans text-[10px] tracking-[0.3em] uppercase font-bold">Impossible questions, one true answer</p>
      </div>

      <div className="space-y-6">
        {ratherQuestions.map((q) => (
          <div 
            key={q.id} 
            className="p-6 rounded-3xl bg-rose-50/30 border border-rose-100/50 transition-all hover:shadow-md group"
          >
            <p className="font-serif text-lg text-gray-700 mb-4 leading-relaxed italic">
              "{q.question}"
            </p>
            
            {!revealed[q.id] ? (
              <button 
                onClick={() => toggleReveal(q.id)}
                className="flex items-center gap-2 text-rose-500 font-bold text-xs uppercase tracking-widest hover:text-rose-600 transition-colors"
              >
                Show Correct Answer <Sparkles className="w-3 h-3" />
              </button>
            ) : (
              <div className="animate-fade-in flex items-start gap-3">
                <div className="flex-shrink-0 mt-1">
                  <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
                </div>
                <div className="flex-grow">
                  <p className="font-serif text-rose-600 font-bold text-lg">
                    {q.answer} <span className="inline-block animate-bounce">❤️😘</span>
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-12 text-center">
        <p className="font-script text-3xl text-rose-400">Because with you, there is no wrong choice.</p>
      </div>
    </div>
  );
};

export default WouldYouRather;