import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

const BackgroundMusic: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Soft, romantic instrumental track
    const audio = new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3');
    audio.loop = true;
    audio.volume = 0.4;
    audioRef.current = audio;

    // Attempt to play on load
    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          setIsPlaying(true);
        })
        .catch((error) => {
          console.log("Autoplay blocked by browser. Music will start on first interaction.", error);
        });
    }

    // Listener for first user interaction to satisfy browser policies
    const handleFirstInteraction = () => {
      if (audioRef.current && !isPlaying) {
        audioRef.current.play()
          .then(() => setIsPlaying(true))
          .catch(e => console.error("Playback failed after interaction:", e));
      }
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('scroll', handleFirstInteraction);
    };

    window.addEventListener('click', handleFirstInteraction);
    window.addEventListener('scroll', handleFirstInteraction);

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('scroll', handleFirstInteraction);
    };
  }, []);

  const togglePlay = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      <button
        onClick={togglePlay}
        className={`
          flex items-center justify-center w-12 h-12 md:w-14 md:h-14 
          rounded-full bg-white/80 backdrop-blur-md shadow-lg border border-rose-100
          transition-all duration-300 hover:scale-110 active:scale-95
          ${isPlaying ? 'text-rose-500' : 'text-gray-400'}
        `}
        aria-label={isPlaying ? "Mute music" : "Play music"}
      >
        <div className="relative">
          {isPlaying && (
            <span className="absolute -inset-2 bg-rose-200 rounded-full animate-ping opacity-20"></span>
          )}
          {isPlaying ? (
            <Volume2 className="w-6 h-6 md:w-7 md:h-7" />
          ) : (
            <VolumeX className="w-6 h-6 md:w-7 md:h-7" />
          )}
        </div>
      </button>
    </div>
  );
};

export default BackgroundMusic;