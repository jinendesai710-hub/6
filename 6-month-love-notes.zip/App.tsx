import React, { useState, useEffect, useCallback, useRef } from 'react';
import { generateLoveContent, getDistanceInfo } from './services/geminiService';
import { LoveContent, AppState, DistanceResult } from './types';
import HeartBackground from './components/HeartBackground';
import AnniversaryCard from './components/AnniversaryCard';
import CoupleEvaluation from './components/CoupleEvaluation';
import LoveQuiz from './components/LoveQuiz';
import WouldYouRather from './components/WouldYouRather';
import LyricSection from './components/LyricSection';
import DistanceCard from './components/DistanceCard';
import { Heart, ChevronDown } from 'lucide-react';

const App: React.FC = () => {
  const [content, setContent] = useState<LoveContent | null>(null);
  const [distanceData, setDistanceData] = useState<DistanceResult | null>(null);
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  
  // Visibility States
  const [cardInView, setCardInView] = useState(false);
  const [distInView, setDistInView] = useState(false);
  const [evalInView, setEvalInView] = useState(false);
  const [quizInView, setQuizInView] = useState(false);
  const [ratherInView, setRatherInView] = useState(false);
  const [lyricInView, setLyricInView] = useState(false);
  const [finalInView, setFinalInView] = useState(false);

  // Section Refs
  const cardSectionRef = useRef<HTMLDivElement>(null);
  const distSectionRef = useRef<HTMLDivElement>(null);
  const evalSectionRef = useRef<HTMLDivElement>(null);
  const quizSectionRef = useRef<HTMLDivElement>(null);
  const ratherSectionRef = useRef<HTMLDivElement>(null);
  const lyricSectionRef = useRef<HTMLDivElement>(null);
  const finalSectionRef = useRef<HTMLDivElement>(null);

  // Intersection Observer to trigger entrance animations on scroll
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.target === cardSectionRef.current && entry.isIntersecting) {
            setCardInView(true);
          }
          if (entry.target === distSectionRef.current && entry.isIntersecting) {
            setDistInView(true);
          }
          if (entry.target === evalSectionRef.current && entry.isIntersecting) {
            setEvalInView(true);
          }
          if (entry.target === quizSectionRef.current && entry.isIntersecting) {
            setQuizInView(true);
          }
          if (entry.target === ratherSectionRef.current && entry.isIntersecting) {
            setRatherInView(true);
          }
          if (entry.target === lyricSectionRef.current && entry.isIntersecting) {
            setLyricInView(true);
          }
          if (entry.target === finalSectionRef.current && entry.isIntersecting) {
            setFinalInView(true);
          }
        });
      },
      { threshold: 0.15 } // Trigger when 15% visible
    );

    if (cardSectionRef.current) observer.observe(cardSectionRef.current);
    if (distSectionRef.current) observer.observe(distSectionRef.current);
    if (evalSectionRef.current) observer.observe(evalSectionRef.current);
    if (quizSectionRef.current) observer.observe(quizSectionRef.current);
    if (ratherSectionRef.current) observer.observe(ratherSectionRef.current);
    if (lyricSectionRef.current) observer.observe(lyricSectionRef.current);
    if (finalSectionRef.current) observer.observe(finalSectionRef.current);

    return () => observer.disconnect();
  }, []);

  // Initial load
  useEffect(() => {
    setAppState(AppState.LOADING);
    Promise.all([
      generateLoveContent(),
      getDistanceInfo()
    ]).then(([newContent, distInfo]) => {
        setContent(newContent);
        setDistanceData(distInfo);
        setAppState(AppState.SUCCESS);
    }).catch((err) => {
        console.error(err);
        setAppState(AppState.ERROR);
    });
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-gradient-to-br from-rose-50 via-white to-pink-50 font-sans text-gray-800 selection:bg-rose-200 overflow-x-hidden">
      
      <HeartBackground />

      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/70 backdrop-blur-xl border-b border-rose-100/30 px-4 md:px-6 py-4 md:py-5 shadow-sm overflow-x-auto no-scrollbar">
        <div className="max-w-6xl mx-auto flex items-center justify-between min-w-max gap-6 md:gap-8">
          <div className="flex items-center gap-2 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
             <Heart className="text-rose-500 fill-rose-500 w-4 h-4 md:w-5 md:h-5 group-hover:scale-125 transition-transform" />
             <span className="font-script text-xl md:text-2xl font-bold bg-gradient-to-r from-rose-800 to-rose-500 bg-clip-text text-transparent">Jinen & Vidhi</span>
          </div>
          <div className="flex gap-4 md:gap-8 text-[9px] md:text-[11px] font-bold tracking-[0.2em] text-gray-400 uppercase">
            <button onClick={() => scrollToSection('love-note')} className="hover:text-rose-600 transition-colors">Note</button>
            <button onClick={() => scrollToSection('distance')} className="hover:text-rose-600 transition-colors">Bridge</button>
            <button onClick={() => scrollToSection('evaluation')} className="hover:text-rose-600 transition-colors">Alchemy</button>
            <button onClick={() => scrollToSection('quiz')} className="hover:text-rose-600 transition-colors">Memory</button>
            <button onClick={() => scrollToSection('choices')} className="hover:text-rose-600 transition-colors">Choices</button>
          </div>
        </div>
      </nav>

      <main className="relative z-10 flex flex-col gap-24 md:gap-32 pb-32">

        {/* Hero Section */}
        <section className="min-h-[90vh] flex flex-col items-center justify-center text-center px-6">
          <div className="space-y-6 max-w-4xl animate-float">
            <h1 className="font-script text-6xl md:text-[10rem] text-rose-500 leading-tight">Six Months my love</h1>
            <p className="font-serif text-lg md:text-3xl text-gray-500 max-w-2xl mx-auto italic leading-relaxed font-light">
              "We are two threads in a vast tapestry, weaving a story that distance can never unravel."
            </p>
            <div className="flex justify-center pt-8">
               <div className="h-12 w-[1px] bg-gradient-to-b from-rose-300 to-transparent"></div>
            </div>
          </div>
          <button 
            onClick={() => scrollToSection('love-note')}
            className="mt-8 transition-all hover:translate-y-2 opacity-60 hover:opacity-100"
          >
            <ChevronDown className="w-8 h-8 text-rose-300" />
          </button>
        </section>

        {/* Love Note Section */}
        <section id="love-note" ref={cardSectionRef} className="min-h-screen flex flex-col items-center justify-center px-4 py-10 scroll-mt-20">
          <div className="mb-12 md:mb-16 text-center space-y-3">
             <h2 className="font-serif text-4xl md:text-5xl text-gray-800 font-light">Written in the Stars</h2>
             <p className="text-rose-400 font-sans text-[10px] tracking-[0.3em] uppercase font-bold">A humanizing letter for your soul</p>
          </div>

          <div className="w-full flex flex-col items-center gap-12">
            {appState === AppState.LOADING && !content ? (
                <div className="flex flex-col items-center gap-6 py-20">
                    <div className="relative">
                      <div className="absolute inset-0 animate-ping bg-rose-200 rounded-full"></div>
                      <div className="relative w-16 h-16 md:w-20 md:h-20 bg-white rounded-full flex items-center justify-center shadow-2xl border border-rose-50">
                        <Heart className="w-8 h-8 md:w-10 md:h-10 text-rose-400 fill-rose-100 animate-pulse" />
                      </div>
                    </div>
                    <p className="font-serif italic text-xl md:text-2xl text-rose-800/60 animate-pulse">Consulting the muse...</p>
                </div>
            ) : content ? (
                <AnniversaryCard 
                  content={content} 
                  isVisible={cardInView} 
                />
            ) : null}
          </div>
        </section>

        {/* Distance Section */}
        <section id="distance" ref={distSectionRef} className="min-h-screen flex flex-col items-center justify-center px-4 py-10 scroll-mt-20">
           <div className="w-full max-w-4xl flex flex-col items-center">
              <div className="mb-12 md:mb-16 text-center space-y-3">
                  <h2 className="font-serif text-4xl md:text-5xl text-gray-800 font-light">The Geography of Us</h2>
                  <p className="text-rose-400 font-sans text-[10px] tracking-[0.3em] uppercase font-bold">Bridging IIM Rohtak & Mumbai</p>
              </div>
              
              <DistanceCard data={distanceData} isVisible={distInView} />
           </div>
        </section>

        {/* Compatibility Evaluation Section */}
        <section id="evaluation" ref={evalSectionRef} className="min-h-screen flex flex-col items-center justify-center px-4 py-10 scroll-mt-20">
           <div className="w-full max-w-4xl flex flex-col items-center">
              <div className="mb-12 md:mb-16 text-center space-y-3">
                  <h2 className="font-serif text-4xl md:text-5xl text-gray-800 font-light">The Sacred Alchemy</h2>
                  <p className="text-rose-400 font-sans text-[10px] tracking-[0.3em] uppercase font-bold">Evaluating the architecture of Jinen & Vidhi</p>
              </div>
              
              <CoupleEvaluation isVisible={evalInView} />
           </div>
        </section>

        {/* Quiz Section */}
        <section id="quiz" ref={quizSectionRef} className="min-h-screen flex flex-col items-center justify-center px-4 py-10 scroll-mt-20">
           <div className="w-full max-w-4xl flex flex-col items-center">
              <div className="mb-12 md:mb-16 text-center space-y-3">
                  <h2 className="font-serif text-4xl md:text-5xl text-gray-800 font-light">The Memory Lane</h2>
                  <p className="text-rose-400 font-sans text-[10px] tracking-[0.3em] uppercase font-bold">Do you remember our milestones?</p>
              </div>
              
              <LoveQuiz isVisible={quizInView} />
           </div>
        </section>

        {/* Would You Rather Section */}
        <section id="choices" ref={ratherSectionRef} className="min-h-screen flex flex-col items-center justify-center px-4 py-10 scroll-mt-20">
           <div className="w-full max-w-4xl flex flex-col items-center">
              <div className="mb-12 md:mb-16 text-center space-y-3">
                  <h2 className="font-serif text-4xl md:text-5xl text-gray-800 font-light">Preferences of the Heart</h2>
                  <p className="text-rose-400 font-sans text-[10px] tracking-[0.3em] uppercase font-bold">The "Would You Rather" challenge</p>
              </div>
              
              <WouldYouRather isVisible={ratherInView} />
           </div>
        </section>

        {/* Lyric/Prayer Section */}
        <section ref={lyricSectionRef} className="scroll-mt-20">
          <LyricSection isVisible={lyricInView} />
        </section>

        {/* Final Message Section */}
        <section ref={finalSectionRef} className="min-h-[70vh] flex flex-col items-center justify-center px-6 py-20 text-center">
          <div 
            className={`
              transition-all duration-[2000ms] ease-out transform space-y-8
              ${finalInView ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-90 translate-y-10'}
            `}
          >
            <h2 className="font-script text-6xl md:text-9xl text-rose-600 drop-shadow-lg leading-tight">
              I will love you, always
            </h2>
            
            <div className="space-y-4 max-w-3xl mx-auto">
              <p className="font-serif text-xl md:text-3xl text-gray-500 italic px-4 leading-relaxed">
                “Six months of distance, countless moments of choosing each other.”
              </p>
            </div>

            <div className="flex justify-center gap-4 md:gap-6 text-rose-400/50 pt-8">
               <Heart className="w-6 h-6 md:w-8 md:h-8 fill-current animate-pulse" />
               <Heart className="w-10 h-10 md:w-12 md:h-12 fill-current animate-pulse delay-75" />
               <Heart className="w-6 h-6 md:w-8 md:h-8 fill-current animate-pulse delay-150" />
            </div>
          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="relative z-10 py-12 text-center border-t border-rose-50 bg-white/40 px-6">
        <div className="max-w-xs mx-auto space-y-4">
          <p className="text-rose-800/40 text-[9px] md:text-[10px] font-bold tracking-[0.4em] uppercase">Happy Anniversary</p>
          <div className="flex items-center justify-center gap-4 opacity-30">
            <div className="h-[1px] flex-grow bg-rose-200"></div>
            <Heart className="w-4 h-4 text-rose-400" />
            <div className="h-[1px] flex-grow bg-rose-200"></div>
          </div>
          <p className="font-serif italic text-gray-400 text-sm">Jinen & Vidhi • Six months</p>
        </div>
      </footer>
    </div>
  );
};

export default App;