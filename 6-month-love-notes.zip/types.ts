export interface DateIdea {
  title: string;
  description: string;
}

export interface LoveContent {
  quote: string;
  dateIdea: DateIdea;
  compliment: string;
}

export interface EvaluationResult {
  score: number;
  analysis: string;
  romanticSummary: string;
}

export interface GroundingChunk {
  maps?: {
    uri: string;
    title: string;
  };
}

export interface DistanceResult {
  text: string;
  links: Array<{ title: string; uri: string }>;
}

export enum AppState {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}