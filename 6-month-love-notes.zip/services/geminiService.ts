import { GoogleGenAI, Type } from "@google/genai";
import { LoveContent, EvaluationResult, DistanceResult, GroundingChunk } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const contentSchema = {
  type: Type.OBJECT,
  properties: {
    quote: {
      type: Type.STRING,
      description: "A romantic, soulful love quote. Use humanizing literature style—evocative, deep, and poetic.",
    },
    compliment: {
      type: Type.STRING,
      description: "A deeply personal and humanizing compliment that highlights the beauty of her soul and presence.",
    },
    dateIdea: {
      type: Type.OBJECT,
      properties: {
        title: { type: Type.STRING, description: "Poetic title of the virtual date idea" },
        description: { type: Type.STRING, description: "An evocative description of a shared virtual experience." }
      },
      required: ["title", "description"]
    }
  },
  required: ["quote", "dateIdea", "compliment"]
};

const evaluationSchema = {
  type: Type.OBJECT,
  properties: {
    score: { type: Type.NUMBER, description: "A compatibility score out of 100 (should be very high, 90-100)." },
    analysis: { type: Type.STRING, description: "A poetic and deeply humanizing analysis of their combined spirits." },
    romanticSummary: { type: Type.STRING, description: "A short piece of romantic literature summarizing their 6-month journey." }
  },
  required: ["score", "analysis", "romanticSummary"]
};

export const generateLoveContent = async (): Promise<LoveContent> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Generate a romantic content pack for Jinen and Vidhi's 6-month anniversary. Style: Humanizing literature. Themes: Shared breath across miles, the architecture of two souls becoming one, and the quiet beauty of long-distance devotion.",
      config: {
        responseMimeType: "application/json",
        responseSchema: contentSchema,
        temperature: 0.9,
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from Gemini");
    }

    return JSON.parse(text) as LoveContent;
  } catch (error) {
    console.error("Error generating content:", error);
    return {
      quote: "Our love is a map where every mile is a heartbeat closer to the home I found in you.",
      compliment: "In the quietest moments of my day, your voice is the only literature my heart cares to read.",
      dateIdea: {
        title: "The Shared Midnight Gallery",
        description: "We'll explore a virtual art museum together, describing the colors not with names, but with the feelings they remind us of regarding our future."
      }
    };
  }
};

export const evaluateRelationship = async (jinenThings: string[], vidhiThings: string[]): Promise<EvaluationResult> => {
  try {
    const prompt = `
      Jinen and Vidhi are celebrating 6 months of profound connection.
      Traits of Jinen's soul (observed by Vidhi): ${jinenThings.join(', ')}.
      Traits of Vidhi's soul (observed by Jinen): ${vidhiThings.join(', ')}.
      
      Evaluate their relationship using humanizing literature. Speak of how these specific traits weave a tapestry of enduring affection.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: evaluationSchema,
        temperature: 0.8,
      },
    });

    const text = response.text;
    if (!text) throw new Error("Empty response");
    
    return JSON.parse(text) as EvaluationResult;
  } catch (error) {
    console.error("Error evaluating:", error);
    return {
      score: 100,
      analysis: "Their bond is a rare manuscript, written in the ink of patience and illuminated by the gold of mutual understanding.",
      romanticSummary: "Jinen and Vidhi have built a bridge of light across the distance, a testament to the fact that two spirits, when truly aligned, know no geography."
    };
  }
};

export const getDistanceInfo = async (): Promise<DistanceResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: "What is the exact travel distance and flight duration between IIM Rohtak and Sion Chunabhatti, Mumbai? Provide a poetic romantic reflection on this distance for a couple named Jinen and Vidhi who have been together for 6 months. Please ensure you identify both distinct locations correctly.",
      config: {
        tools: [{ googleMaps: {} }],
      },
    });

    const text = response.text || "Distance is a test of how far love can travel.";
    
    // Explicitly return only the two links requested by the user
    const links = [
      { title: "IIM Rohtak", uri: "https://www.google.com/maps/search/IIM+Rohtak" },
      { title: "Sion Chunabhatti", uri: "https://www.google.com/maps/search/Sion+Chunabhatti+Mumbai" }
    ];

    return { text, links };
  } catch (error) {
    console.error("Error getting distance:", error);
    return {
      text: "The distance between IIM Rohtak and Sion Chunabhatti is approximately 1,400 kilometers. Though miles separate Jinen and Vidhi, their hearts beat in synchronized rhythm, proving that love has no boundaries.",
      links: [
        { title: "IIM Rohtak", uri: "https://www.google.com/maps/search/IIM+Rohtak" },
        { title: "Sion Chunabhatti", uri: "https://www.google.com/maps/search/Sion+Chunabhatti+Mumbai" }
      ]
    };
  }
};