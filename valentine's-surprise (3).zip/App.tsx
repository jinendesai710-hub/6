
import React, { useState, useCallback, useRef } from 'react';
import Penguin from './components/Penguin';
import FallingHearts from './components/FallingHearts';
import LoveLetter from './components/LoveLetter';
import Confetti from './components/Confetti';
import SpecialMoment from './components/SpecialMoment';
import Sunflowers from './components/Sunflowers';

export enum Stage {
  ASKING = 'ASKING',
  REJECTED = 'REJECTED',
  CELEBRATING = 'CELEBRATING',
  ACCEPTED = 'ACCEPTED'
}

const App: React.FC = () => {
  const [stage, setStage] = useState<Stage>(Stage.ASKING);
  const [noButtonPos, setNoButtonPos] = useState({ x: 0, y: 0 });
  const [hasInteracted, setHasInteracted] = useState(false);
  const [yesScale, setYesScale] = useState(1);
  const [noClickCount, setNoClickCount] = useState(0);
  const noButtonRef = useRef<HTMLButtonElement>(null);

  const handleNoInteraction = useCallback((e?: React.MouseEvent | React.TouchEvent) => {
    const padding = 50;
    const btnWidth = noButtonRef.current?.offsetWidth || 100;
    const btnHeight = noButtonRef.current?.offsetHeight || 50;

    const maxX = window.innerWidth - btnWidth - padding;
    const maxY = window.innerHeight - btnHeight - padding;
    
    const randomX = Math.max(padding, Math.random() * maxX);
    const randomY = Math.max(padding, Math.random() * maxY);

    setNoButtonPos({ x: randomX, y: randomY });
    setHasInteracted(true);
    setYesScale(prev => Math.min(prev + 0.15, 3.5));
    setNoClickCount(prev => prev + 1);

    if (e && 'preventDefault' in e) e.preventDefault();
  }, []);

  const handleNoClick = (e: React.MouseEvent) => {
    if (noClickCount < 12) {
      handleNoInteraction(e);
    } else {
      setStage(Stage.REJECTED);
    }
  };

  const handleYesClick = () => {
    setStage(Stage.CELEBRATING);
    setTimeout(() => {
      setStage(Stage.ACCEPTED);
    }, 2500);
  };

  const reset = () => {
    setStage(Stage.ASKING);
    setHasInteracted(false);
    setNoButtonPos({ x: 0, y: 0 });
    setYesScale(1);
    setNoClickCount(0);
  };

  const getAskingTitle = () => {
    if (noClickCount === 0) return "Will you be my Valentine?";
    if (noClickCount < 4) return "Wait, come back! 🥺";
    if (noClickCount < 8) return "Don't you love me? 🐧";
    return "Click Yes already! 😂";
  };

  return (
    <div className="min-h-screen h-screen w-full flex flex-col items-center justify-center transition-all duration-1000 overflow-hidden relative bg-[#D32F2F]">
      
      {/* Background Decor */}
      <FallingHearts 
        colorTheme={stage === Stage.ACCEPTED ? 'red' : 'white'} 
        mode={stage === Stage.ACCEPTED ? 'fall' : 'float'} 
      />

      {(stage === Stage.ACCEPTED || stage === Stage.CELEBRATING) && (
        <div className="absolute inset-0 z-0">
           <div className="absolute inset-0 bg-gradient-to-br from-[#D32F2F] via-[#b91c1c] to-[#991b1b] opacity-95"></div>
           <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/pinstriped-suit.png')] opacity-10"></div>
        </div>
      )}
      
      <div className="z-10 text-center w-full h-full flex flex-col items-center justify-center overflow-hidden">
        {stage === Stage.ASKING && (
          <div className="animate-in fade-in zoom-in duration-700 flex flex-col items-center px-4 w-full">
            <h1 className="text-4xl sm:text-6xl md:text-8xl font-romantic text-white mb-12 drop-shadow-2xl">
              {getAskingTitle()}
            </h1>
            
            <div className="mb-12 w-40 h-40 sm:w-64 sm:h-64">
              <Penguin state={noClickCount > 6 ? 'angry' : 'happy'} />
            </div>

            <div className="flex flex-col sm:flex-row gap-6 sm:gap-12 items-center justify-center w-full min-h-[120px]">
              <button
                onClick={handleYesClick}
                style={{ transform: `scale(${yesScale})`, zIndex: 100 }}
                className="px-12 py-5 bg-white text-red-600 rounded-full font-bold text-2xl shadow-2xl active:scale-95 transition-all border-b-8 border-gray-200"
              >
                Yes! ❤️
              </button>

              <button
                ref={noButtonRef}
                onMouseEnter={() => handleNoInteraction()}
                onTouchStart={() => handleNoInteraction()}
                onClick={handleNoClick}
                style={{ 
                  left: hasInteracted ? `${noButtonPos.x}px` : 'auto',
                  top: hasInteracted ? `${noButtonPos.y}px` : 'auto',
                  position: hasInteracted ? 'fixed' : 'relative',
                  zIndex: 50
                }}
                className="px-8 py-3 bg-red-900/40 text-red-100 border-2 border-red-400/30 rounded-full font-bold text-xl shadow-lg whitespace-nowrap"
              >
                No
              </button>
            </div>
          </div>
        )}

        {stage === Stage.CELEBRATING && (
          <div className="animate-in fade-in zoom-in duration-500 flex flex-col items-center">
            <Confetti />
            <h1 className="text-7xl sm:text-9xl font-romantic text-white mb-10 drop-shadow-2xl animate-bounce">
              YAYYY! ❤️
            </h1>
            <div className="w-64 h-64 sm:w-96 sm:h-96">
              <Penguin state="celebrate" />
            </div>
          </div>
        )}

        {stage === Stage.REJECTED && (
          <div className="animate-in slide-in-from-bottom-10 duration-500 flex flex-col items-center px-4">
            <h1 className="text-4xl sm:text-6xl font-romantic text-white mb-8">Try again, Vidhi! 🐧</h1>
            <div className="mb-10 w-56 h-56">
              <Penguin state="angry" />
            </div>
            <button
              onClick={reset}
              className="px-12 py-5 bg-white text-red-600 rounded-full font-bold text-2xl shadow-2xl border-b-4 border-gray-200"
            >
              Let me fix that!
            </button>
          </div>
        )}

        {stage === Stage.ACCEPTED && (
          <div className="flex flex-col items-center w-full h-full animate-in fade-in duration-1000 overflow-y-auto no-scrollbar pt-10 pb-20">
            <div className="mb-12 bg-black/20 backdrop-blur-md px-10 py-6 rounded-3xl border border-white/10 shadow-2xl max-w-[90%] sm:max-w-2xl transform hover:scale-[1.02] transition-transform">
               <h2 className="text-2xl sm:text-4xl font-romantic text-white italic text-center leading-snug">
                 Distance means so little when someone means so much.
               </h2>
            </div>

            <div className="w-full max-w-4xl px-4">
              <LoveLetter />
            </div>
            
            <div className="w-full max-w-4xl px-4 mt-10">
              <Sunflowers />
            </div>

            <div className="w-full max-w-4xl px-4 mt-10 mb-20">
              <SpecialMoment />
            </div>

            {/* Scroll Indicator */}
            <div className="fixed bottom-6 left-1/2 -translate-x-1/2 animate-bounce flex flex-col items-center text-white/40 pointer-events-none">
               <span className="text-xs uppercase tracking-widest font-bold mb-2">Scroll for more</span>
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
               </svg>
            </div>
          </div>
        )}
      </div>

      {stage === Stage.ASKING && (
        <div className="absolute bottom-10 text-white/30 text-xs font-bold tracking-[0.4em] uppercase animate-pulse">
          With Love • Jinen
        </div>
      )}
    </div>
  );
};

export default App;
