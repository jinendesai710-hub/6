
import React, { useEffect, useState } from 'react';

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
  type: string;
}

interface FallingHeartsProps {
  colorTheme?: 'red' | 'cyan' | 'white';
  mode?: 'fall' | 'float';
}

const FallingHearts: React.FC<FallingHeartsProps> = ({ colorTheme = 'red', mode = 'fall' }) => {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    const redTypes = ['❤️', '🍎', '🌹', '🎈', '✨', '🍓', '🥀', '💋', '💖', '🤍'];
    const cyanTypes = ['✨', '💎', '❄️', '🧊', '🤍', '⭐', '🌊', '💨', '💚', '💙'];
    const whiteTypes = ['🤍', '✨', '🤍', '☁️', '🤍', '⭐', '🤍'];
    
    let types = redTypes;
    if (colorTheme === 'cyan') types = cyanTypes;
    else if (colorTheme === 'white') types = whiteTypes;
    
    const count = mode === 'fall' ? 50 : 35; // Slightly more for better coverage
    const newParticles = Array.from({ length: count }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * (mode === 'fall' ? 20 : 18) + 12,
      duration: Math.random() * (mode === 'fall' ? 6 : 12) + (mode === 'fall' ? 4 : 8),
      delay: Math.random() * 5,
      type: types[i % types.length]
    }));
    setParticles(newParticles);
  }, [colorTheme, mode]);

  // Determine opacity based on theme
  const baseOpacity = colorTheme === 'white' ? 'opacity-70' : 'opacity-30';

  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {particles.map((p) => (
        <div
          key={p.id}
          className={`absolute ${baseOpacity} ${mode === 'fall' ? 'animate-fall' : 'animate-float-stable'} text-white`}
          style={{
            left: `${p.x}%`,
            top: mode === 'fall' ? '-50px' : `${p.y}%`,
            fontSize: `${p.size}px`,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
            filter: colorTheme === 'white' ? 'drop-shadow(0 0 8px rgba(255, 255, 255, 0.8))' : 'none'
          }}
        >
          {p.type}
        </div>
      ))}
      <style>{`
        @keyframes fall {
          0% { transform: translateY(-10vh) rotate(0deg); opacity: 0; }
          10% { opacity: 0.5; }
          90% { opacity: 0.5; }
          100% { transform: translateY(110vh) rotate(360deg); opacity: 0; }
        }
        @keyframes float-stable {
          0%, 100% { transform: translate(0, 0) rotate(0deg); opacity: 0.4; }
          50% { transform: translate(20px, -35px) rotate(20deg); opacity: 0.8; }
        }
        .animate-fall {
          animation: fall linear infinite;
        }
        .animate-float-stable {
          animation: float-stable ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default FallingHearts;
