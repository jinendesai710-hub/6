
import React from 'react';

interface PenguinProps {
  state: 'happy' | 'angry' | 'love' | 'celebrate';
}

const Penguin: React.FC<PenguinProps> = ({ state }) => {
  return (
    <div className={`relative w-full h-full mx-auto ${state === 'celebrate' ? 'animate-celebrate-jump' : ''}`}>
      <svg
        viewBox="0 0 200 200"
        className="w-full h-full transition-transform duration-500"
      >
        {/* Shadow */}
        <ellipse cx="100" cy="185" rx="40" ry="10" fill="#000000" fillOpacity="0.1" />

        {/* Body */}
        <ellipse cx="100" cy="110" rx="52" ry="72" fill="#2D3436" />
        <ellipse cx="100" cy="120" rx="40" ry="58" fill="#FFFFFF" />
        
        {/* Flippers */}
        <g style={{ transformOrigin: 'center 110px' }}>
          {/* Left Wing */}
          <path 
            d="M50,110 Q25,120 40,150" 
            stroke="#2D3436" 
            strokeWidth="16" 
            strokeLinecap="round" 
            fill="none" 
            className={state === 'celebrate' ? 'animate-wing-wave-left' : ''}
            style={{ transformOrigin: '50px 110px' }}
          />
          {/* Right Wing */}
          <path 
            d="M150,110 Q175,120 160,150" 
            stroke="#2D3436" 
            strokeWidth="16" 
            strokeLinecap="round" 
            fill="none" 
            className={state === 'celebrate' ? 'animate-wing-wave-right' : ''}
            style={{ transformOrigin: '150px 110px' }}
          />
        </g>

        {/* Feet */}
        <ellipse cx="78" cy="178" rx="14" ry="7" fill="#FF9F43" />
        <ellipse cx="122" cy="178" rx="14" ry="7" fill="#FF9F43" />

        {/* Face */}
        <g>
          <defs>
            <filter id="eyeGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="blur" />
              <feColorMatrix in="blur" type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1 0" />
              <feMerge>
                <feMergeNode />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Eyes - Big and Glowing */}
          {(state === 'happy' || state === 'celebrate' || state === 'love') && (
            <>
              <circle cx="82" cy="85" r="14" fill="#FFFFFF" fillOpacity="0.4" filter="url(#eyeGlow)" className="animate-pulse-fast" />
              <circle cx="118" cy="85" r="14" fill="#FFFFFF" fillOpacity="0.4" filter="url(#eyeGlow)" className="animate-pulse-fast" />
              
              <circle cx="82" cy="85" r="11" fill="#2D3436" />
              <circle cx="118" cy="85" r="11" fill="#2D3436" />
              
              <circle cx="85" cy="81" r="4.5" fill="#FFFFFF" />
              <circle cx="121" cy="81" r="4.5" fill="#FFFFFF" />
              <circle cx="78" cy="88" r="2" fill="#FFFFFF" fillOpacity="0.6" />
              <circle cx="114" cy="88" r="2" fill="#FFFFFF" fillOpacity="0.6" />
              
              <circle cx="72" cy="102" r="9" fill="#FF5252" fillOpacity="0.3" />
              <circle cx="128" cy="102" r="9" fill="#FF5252" fillOpacity="0.3" />
            </>
          )}

          {state === 'angry' && (
            <>
              <path d="M72,78 L88,86" stroke="#2D3436" strokeWidth="4" strokeLinecap="round" />
              <path d="M128,78 L112,86" stroke="#2D3436" strokeWidth="4" strokeLinecap="round" />
              <circle cx="82" cy="98" r="10" fill="#2D3436" />
              <circle cx="118" cy="98" r="10" fill="#2D3436" />
              <path d="M92,145 Q100,135 108,145" stroke="#2D3436" strokeWidth="3" fill="none" />
            </>
          )}

          {/* Beak */}
          <path d="M92,108 L108,108 L100,120 Z" fill="#FF9F43" />
        </g>
        
        {/* Scarf */}
        <path d="M75,130 Q100,140 125,130 L125,140 Q100,150 75,140 Z" fill="#D63031" />
      </svg>
      
      <style>{`
        @keyframes pulse-fast {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.1); }
        }
        .animate-pulse-fast {
          animation: pulse-fast 1s ease-in-out infinite;
          transform-origin: center;
        }
        @keyframes celebrate-jump {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-40px); }
        }
        .animate-celebrate-jump {
          animation: celebrate-jump 0.5s ease-in-out infinite;
        }
        @keyframes wing-wave-left {
          0%, 100% { transform: rotate(0deg); }
          50% { transform: rotate(-40deg); }
        }
        @keyframes wing-wave-right {
          0%, 100% { transform: rotate(0deg); }
          50% { transform: rotate(40deg); }
        }
        .animate-wing-wave-left {
          animation: wing-wave-left 0.5s ease-in-out infinite;
        }
        .animate-wing-wave-right {
          animation: wing-wave-right 0.5s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default Penguin;
