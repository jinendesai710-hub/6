
import React, { useEffect, useState } from 'react';

interface ConfettiPiece {
  id: number;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  color: string;
  size: number;
  delay: number;
  rotation: number;
  shape: 'circle' | 'square' | 'triangle';
}

const Confetti: React.FC = () => {
  const [pieces, setPieces] = useState<ConfettiPiece[]>([]);

  useEffect(() => {
    const colors = ['#FFD700', '#FF69B4', '#FF1493', '#FFFFFF', '#FF4500', '#00FFFF', '#ADFF2F'];
    const shapes: ('circle' | 'square' | 'triangle')[] = ['circle', 'square', 'triangle'];
    
    const newPieces = Array.from({ length: 120 }).map((_, i) => ({
      id: i,
      x: 50, // Start from center
      y: 50,
      targetX: Math.random() * 300 - 150, // Wide burst
      targetY: Math.random() * 300 - 150,
      color: colors[Math.floor(Math.random() * colors.length)],
      size: Math.random() * 8 + 6,
      delay: Math.random() * 0.1,
      rotation: Math.random() * 720,
      shape: shapes[Math.floor(Math.random() * shapes.length)]
    }));
    setPieces(newPieces);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[100] overflow-hidden">
      {pieces.map((p) => (
        <div
          key={p.id}
          className={`absolute animate-confetti-burst ${
            p.shape === 'circle' ? 'rounded-full' : p.shape === 'square' ? 'rounded-sm' : ''
          }`}
          style={{
            backgroundColor: p.shape === 'triangle' ? 'transparent' : p.color,
            borderLeft: p.shape === 'triangle' ? `${p.size / 2}px solid transparent` : 'none',
            borderRight: p.shape === 'triangle' ? `${p.size / 2}px solid transparent` : 'none',
            borderBottom: p.shape === 'triangle' ? `${p.size}px solid ${p.color}` : 'none',
            width: p.shape === 'triangle' ? '0' : `${p.size}px`,
            height: p.shape === 'triangle' ? '0' : `${p.size}px`,
            left: `${p.x}%`,
            top: `${p.y}%`,
            '--target-x': `${p.targetX}vw`,
            '--target-y': `${p.targetY}vh`,
            '--rotation': `${p.rotation}deg`,
            animationDelay: `${p.delay}s`,
            opacity: 0,
          } as React.CSSProperties}
        />
      ))}
      <style>{`
        @keyframes confetti-burst {
          0% {
            transform: translate(-50%, -50%) scale(0) rotate(0deg);
            opacity: 1;
          }
          15% {
            opacity: 1;
          }
          100% {
            transform: translate(calc(var(--target-x) - 50%), calc(var(--target-y) - 50%)) scale(1) rotate(var(--rotation));
            opacity: 0;
          }
        }
        .animate-confetti-burst {
          animation: confetti-burst 2.2s cubic-bezier(0.1, 0.8, 0.3, 1) forwards;
        }
      `}</style>
    </div>
  );
};

export default Confetti;
