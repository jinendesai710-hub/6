
import React from 'react';

const SpecialMoment: React.FC = () => {
  const clipUrl = "https://youtube.com/clip/Ugkx3DE1UbNxfuH17Afk4YPLvLS5Yea6S3OZ?si=Wyd46VYIEDsRaFys";

  return (
    <div className="relative w-full flex flex-col items-center justify-center py-16 px-4 animate-section-in">
      <div className="absolute w-72 h-72 bg-red-400/10 rounded-full blur-[120px] -z-10 animate-pulse"></div>
      
      <div className="max-w-xl w-full group relative">
        <a 
          href={clipUrl} 
          target="_blank" 
          rel="noopener noreferrer"
          className="block relative overflow-hidden rounded-[2.5rem] shadow-[0_35px_80px_rgba(0,0,0,0.6)] border-4 border-white/20 transition-all duration-700 hover:shadow-[0_45px_100px_rgba(220,38,38,0.4)] hover:-translate-y-4"
        >
          <div className="aspect-video bg-gradient-to-br from-red-950 via-red-900 to-black relative flex items-center justify-center">
            <img 
              src="https://images.unsplash.com/photo-1516589174184-c68526614fd5?auto=format&fit=crop&q=80&w=1200" 
              alt="Romantic Moment"
              className="absolute inset-0 w-full h-full object-cover opacity-70 mix-blend-overlay group-hover:scale-110 transition-transform duration-1000"
            />
            
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden">
               <span className="text-[14vw] sm:text-[110px] font-bold text-white/[0.04] tracking-tighter transform -rotate-12 whitespace-nowrap uppercase">
                  12.08.2025
               </span>
            </div>

            <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-500"></div>

            <div className="relative z-10 w-24 h-24 bg-white/10 backdrop-blur-2xl rounded-full flex items-center justify-center border-2 border-white/30 group-hover:scale-110 group-hover:bg-white/20 transition-all duration-500 group-hover:shadow-[0_0_50px_rgba(255,255,255,0.3)]">
              <svg className="w-12 h-12 text-white fill-current ml-1" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
            
            <div className="absolute bottom-8 left-10 right-10 text-white text-left z-20">
              <p className="font-romantic text-4xl sm:text-5xl drop-shadow-2xl mb-2">You, through my eyes</p>
              <p className="text-white/50 text-xs sm:text-sm uppercase tracking-[0.4em] font-bold">A special clip for you 🎬</p>
            </div>
          </div>
        </a>

        <div className="absolute -top-8 -left-8 text-6xl animate-bounce drop-shadow-2xl" style={{ animationDelay: '0.2s' }}>💝</div>
        <div className="absolute -bottom-6 -right-10 text-7xl animate-bounce drop-shadow-2xl" style={{ animationDelay: '0.5s' }}>💖</div>
      </div>

      <p className="mt-16 text-white/50 font-romantic text-2xl sm:text-4xl italic text-center max-w-lg px-4">
        "Every second with you is a treasure."
      </p>

      <style>{`
        @keyframes section-in {
          0% { opacity: 0; transform: translateY(40px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .animate-section-in {
          animation: section-in 2.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          animation-delay: 15s;
          opacity: 0;
          animation-fill-mode: forwards;
        }
      `}</style>
    </div>
  );
};

export default SpecialMoment;
