
import React, { useEffect, useState, useRef, useMemo } from 'react';

interface WordRevealProps {
  text: string;
  baseDelay: number;
  wordSpeed?: number;
  active: boolean;
  className?: string;
}

const WordReveal: React.FC<WordRevealProps> = ({ text, baseDelay, wordSpeed = 0.08, active, className }) => {
  const words = useMemo(() => text.split(' '), [text]);

  return (
    <span className={className}>
      {words.map((word, i) => (
        <span
          key={i}
          className="inline-block"
          style={{
            opacity: active ? 1 : 0,
            filter: active ? 'blur(0)' : 'blur(4px)',
            transform: active ? 'translateY(0)' : 'translateY(4px)',
            transition: active 
              ? `opacity 0.6s ease-out ${baseDelay + i * wordSpeed}s, 
                 filter 0.8s ease-out ${baseDelay + i * wordSpeed}s, 
                 transform 0.6s cubic-bezier(0.16, 1, 0.3, 1) ${baseDelay + i * wordSpeed}s`
              : 'none',
            marginRight: '0.25em'
          }}
        >
          {word}
        </span>
      ))}
    </span>
  );
};

const LoveLetter: React.FC = () => {
  const [scrollY, setScrollY] = useState(0);
  const [isEnvelopeOpen, setIsEnvelopeOpen] = useState(false);
  const [showFullLetter, setShowFullLetter] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const scrollContainer = containerRef.current?.closest('.overflow-y-auto');
    const handleScroll = () => {
      if (scrollContainer) {
        setScrollY(scrollContainer.scrollTop);
      }
    };
    if (scrollContainer) {
      scrollContainer.addEventListener('scroll', handleScroll, { passive: true });
    }
    return () => {
      if (scrollContainer) {
        scrollContainer.removeEventListener('scroll', handleScroll);
      }
    };
  }, []);

  const textureShift = scrollY * 0.05;
  const contentShift = scrollY * -0.01;

  const sparkles = [
    { id: 1, top: '-15%', left: '15%', delay: '0s', size: '8px', type: 'star' },
    { id: 2, top: '25%', left: '-20%', delay: '0.8s', size: '6px', type: 'dot' },
    { id: 3, top: '75%', left: '-15%', delay: '1.5s', size: '10px', type: 'star' },
    { id: 4, top: '95%', left: '45%', delay: '2.2s', size: '5px', type: 'dot' },
    { id: 5, top: '55%', left: '115%', delay: '0.4s', size: '9px', type: 'star' },
    { id: 6, top: '-5%', left: '85%', delay: '1.9s', size: '6px', type: 'dot' },
    { id: 7, top: '40%', left: '110%', delay: '3.1s', size: '7px', type: 'star' },
    { id: 8, top: '10%', left: '-10%', delay: '2.5s', size: '5px', type: 'dot' },
  ];

  const handleEnvelopeClick = () => {
    if (!isEnvelopeOpen) {
      setIsEnvelopeOpen(true);
      setTimeout(() => {
        setShowFullLetter(true);
      }, 700);
    }
  };

  const intro = "Vidhi,";
  const p1 = "Happy Valentine's Day, my love. Even though we are miles apart today, I feel your presence in every heartbeat. This is our very first Valentine's together, and while I wish I could be there to hold you and tell you how much you mean to me in person, I am so grateful that I can call you mine.";
  const p2 = "Long distance isn't just about the miles; it's about the strength of the love that bridges them. Every virtual date, every long call after your classes, and every \"I love you\" whispered through a screen makes me realize how lucky I am to have found someone worth waiting for. You are my home, no matter where we are.";
  const p3 = "Thank you for being the incredible woman you are. Our love is resilient—\"strong che aapde\"—and nothing can change that. I am counting down the days until the screen disappears and it's just us again. Until then, know that you have my whole heart, today and every day.";

  return (
    <div 
      ref={containerRef}
      className="relative w-full px-2 sm:px-4 flex flex-col justify-center items-center py-6 sm:py-10"
    >
      <svg className="absolute w-0 h-0 invisible" aria-hidden="true">
        <filter id="paper-edge">
          <feTurbulence type="fractalNoise" baseFrequency="0.03 0.1" numOctaves="4" seed="2" result="noise" />
          <feDisplacementMap in="SourceGraphic" in2="noise" scale="7" xChannelSelector="R" yChannelSelector="G" />
        </filter>
        <filter id="fiber-texture">
          <feTurbulence type="fractalNoise" baseFrequency="0.6" numOctaves="3" result="noise" />
          <feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.15 0" />
        </filter>
      </svg>

      <div className={`relative transition-all duration-1000 ease-in-out ${showFullLetter ? 'w-full' : 'w-72 h-48 sm:w-96 sm:h-64 cursor-pointer hover:scale-105 active:scale-95'} perspective-1000`}>
        
        {/* ENVELOPE BASE */}
        <div 
          onClick={handleEnvelopeClick}
          className={`group absolute inset-0 z-30 transition-all duration-700 ease-in-out transform-style-3d ${showFullLetter ? 'opacity-0 scale-90 translate-y-20 pointer-events-none' : 'opacity-100 scale-100'}`}
        >
          <div className="absolute inset-0 bg-[#f5e6d3] shadow-2xl rounded-sm z-10 border border-[#e8d7c0]"></div>
          
          <div 
            className={`absolute top-0 left-0 w-full h-full transform-origin-top transition-transform duration-700 ease-in-out z-0 bg-[#d8c7b3] ${isEnvelopeOpen ? 'rotate-x-180' : 'rotate-x-0'}`}
            style={{ clipPath: 'polygon(0 0, 100% 0, 50% 60%)' }}
          ></div>

          <div 
            className={`absolute top-0 left-0 w-full h-full transform-origin-top transition-transform duration-700 ease-in-out z-40 backface-hidden shadow-md ${isEnvelopeOpen ? 'rotate-x-[-180deg]' : 'group-hover:rotate-x-[-25deg]'}`}
            style={{
              clipPath: 'polygon(0 0, 100% 0, 50% 60%)',
              backgroundColor: '#e6d5c0',
            }}
          >
            <div className={`absolute top-[35%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 sm:w-16 sm:h-16 transition-opacity duration-300 ${isEnvelopeOpen ? 'opacity-0' : 'opacity-100'}`}>
              <div className="w-full h-full bg-gradient-to-br from-[#800000] via-[#b91c1c] to-[#450a0a] rounded-full flex items-center justify-center shadow-lg border-2 border-[#3f0000] transform -rotate-12">
                <span className="text-white text-xl sm:text-2xl">❤️</span>
              </div>
            </div>
          </div>

          <div 
            className="absolute inset-0 z-30 pointer-events-none"
            style={{
              clipPath: 'polygon(0 0, 15% 50%, 0 100%, 100% 100%, 85% 50%, 100% 0)',
              backgroundColor: '#f1dec8',
            }}
          ></div>

          <div 
            className="absolute bottom-0 left-0 w-full h-2/3 z-20 pointer-events-none"
            style={{
              clipPath: 'polygon(0 100%, 100% 100%, 50% 0)',
              backgroundColor: '#ebd9c3',
            }}
          ></div>

          <div className={`absolute inset-x-0 -bottom-10 text-center text-white/80 font-romantic text-2xl transition-opacity duration-300 ${isEnvelopeOpen ? 'opacity-0' : 'opacity-100 animate-bounce'}`}>
            Click to Open 💌
          </div>
        </div>

        {/* FULL LETTER */}
        <div className={`transition-all duration-1000 transform ${showFullLetter ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-40 scale-75 pointer-events-none'}`}>
          <div className="relative w-full p-1 sm:p-2 rounded-lg bg-white/10 shadow-[0_40px_100px_rgba(0,0,0,0.6)] backdrop-blur-sm">
            <div 
              className="relative bg-[#fffef4] p-4 sm:p-8 md:p-12 shadow-2xl transition-transform duration-700 overflow-hidden w-full select-none rounded-sm min-h-[600px]"
            >
              <div 
                className="absolute inset-0 pointer-events-none"
                style={{
                  backgroundImage: `
                    repeating-linear-gradient(transparent, transparent 23px, #cbd5e1 23px, #cbd5e1 24px),
                    linear-gradient(to right, #fecaca 3px, transparent 3px),
                    radial-gradient(circle at 15% 25%, rgba(218, 165, 32, 0.08) 0%, transparent 45%),
                    radial-gradient(circle at 85% 75%, rgba(139, 69, 19, 0.05) 0%, transparent 40%),
                    linear-gradient(to bottom, rgba(0,0,0,0.02) 0%, transparent 5%, transparent 95%, rgba(0,0,0,0.02) 100%)
                  `,
                  backgroundSize: '100% 24px, 45px 100%, 100% 100%, 100% 100%, 100% 100%',
                  backgroundPosition: `0 ${-textureShift * 0.2}px, 45px 0, 0 0, 0 0, 0 0`,
                  filter: 'url(#paper-edge)',
                }}
              >
                <div className="absolute inset-0 pointer-events-none opacity-20" style={{ filter: 'url(#fiber-texture)' }}></div>
                <div className="absolute inset-0 opacity-40 pointer-events-none mix-blend-multiply" style={{ backgroundImage: 'url("https://www.transparenttextures.com/patterns/natural-paper.png")', backgroundPosition: `0px ${textureShift * 0.1}px` }}></div>
              </div>

              <div className="absolute top-4 right-4 sm:top-8 sm:right-10 w-16 h-16 sm:w-24 sm:h-24 z-20 group" style={{ transform: `translateY(${textureShift * -0.05}px)` }}>
                <div className="w-full h-full bg-gradient-to-br from-[#800000] via-[#b91c1c] to-[#450a0a] rounded-full flex items-center justify-center shadow-xl border-[4px] border-[#3f0000] transform -rotate-12 transition-all hover:scale-110">
                  <span className="text-white text-3xl sm:text-5xl">❤️</span>
                </div>
              </div>
              
              <div className="relative z-10 w-full pl-10 sm:pl-20 md:pl-24 pr-4 sm:pr-8 py-8" style={{ transform: `translateY(${contentShift}px)` }}>
                <div className="font-archivo text-red-950 text-4xl sm:text-6xl md:text-7xl mb-10 sm:mb-14 leading-none font-bold tracking-tight">
                  <WordReveal text={intro} baseDelay={0.5} active={showFullLetter} />
                </div>
                
                <div className="text-[#1a1a1a] leading-[1.7] sm:leading-[2] space-y-6 sm:space-y-8 text-xl sm:text-2xl md:text-3xl text-left font-archivo tracking-tight font-semibold">
                  <p><WordReveal text={p1} baseDelay={1.0} active={showFullLetter} /></p>
                  <p><WordReveal text={p2} baseDelay={5.0} active={showFullLetter} /></p>
                  <p><WordReveal text={p3} baseDelay={9.0} active={showFullLetter} /></p>
                  
                  <div className="text-right mt-16 sm:mt-24 pr-2 sm:pr-6">
                    <div className="font-archivo text-2xl sm:text-4xl text-red-950 mb-2 font-bold">
                       <WordReveal text="Forever Yours," baseDelay={13.0} active={showFullLetter} />
                    </div>
                    <div className="font-archivo text-3xl sm:text-5xl text-red-900 font-extrabold tracking-tighter">
                       <WordReveal text="Jinen." baseDelay={13.5} active={showFullLetter} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-12 sm:mt-20 text-white font-bold text-center text-4xl sm:text-7xl animate-pulse-glow tracking-[0.1em] sm:tracking-[0.2em] uppercase font-romantic opacity-0 animate-fade-in drop-shadow-[0_0_20px_rgba(255,255,255,0.8)]" style={{ animationDelay: '15s', animationFillMode: 'forwards' }}>
            Happy Valentine's Day! 🌻
          </div>
        </div>
      </div>

      <style>{`
        .perspective-1000 { perspective: 1200px; }
        .transform-style-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .transform-origin-top { transform-origin: top; }
        .rotate-x-180 { transform: rotateX(180deg); }
        .rotate-x-\[-180deg\] { transform: rotateX(-180deg); }
        .font-archivo { font-family: 'Archivo', sans-serif; }
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in { animation: fade-in 2s ease-out forwards; }
        @keyframes pulse-glow {
          0%, 100% { filter: drop-shadow(0 0 10px rgba(255, 255, 255, 0.4)); transform: scale(1); }
          50% { filter: drop-shadow(0 0 40px rgba(255, 255, 255, 0.8)); transform: scale(1.05); }
        }
        .animate-pulse-glow { animation: pulse-glow 5s ease-in-out infinite; }
      `}</style>
    </div>
  );
};

export default LoveLetter;
