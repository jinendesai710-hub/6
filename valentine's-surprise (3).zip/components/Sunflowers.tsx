
import React from 'react';

const Sunflowers: React.FC = () => {
  return (
    <div className="relative w-full flex flex-col items-center justify-center py-12 px-4 animate-bouquet-in">
      <div className="absolute w-64 h-64 sm:w-96 sm:h-96 bg-yellow-400/10 rounded-full blur-[100px] -z-10 animate-pulse"></div>
      
      <div className="relative max-w-2xl w-full group">
        <img 
          src="https://images.unsplash.com/photo-1594315590298-329f49c7dcb9?auto=format&fit=crop&q=80&w=1200" 
          alt="Sunflower Bouquet" 
          className="w-full h-auto rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.6)] border-4 border-white/10 group-hover:scale-[1.03] transition-transform duration-1000 ease-out"
        />
        
        <div className="absolute -bottom-6 -right-4 sm:-right-8 bg-white px-8 py-4 rounded-2xl shadow-2xl transform rotate-2 border-b-4 border-gray-100">
           <span className="text-red-600 font-romantic text-3xl sm:text-4xl font-bold whitespace-nowrap">For Vidhi 🌻</span>
        </div>
      </div>

      <p className="mt-16 text-yellow-50 font-romantic text-2xl sm:text-4xl opacity-80 text-center max-w-lg italic px-4">
        "Like sunflowers, my love always turns towards you."
      </p>

      <style>{`
        @keyframes bouquet-in {
          0% { opacity: 0; transform: translateY(40px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .animate-bouquet-in {
          animation: bouquet-in 2s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          animation-delay: 13s;
          opacity: 0;
          animation-fill-mode: forwards;
        }
      `}</style>
    </div>
  );
};

export default Sunflowers;
